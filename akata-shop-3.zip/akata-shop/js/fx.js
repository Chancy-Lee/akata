(()=>{const bar=document.createElement("div");bar.id="bar";document.body.prepend(bar);const h=$("header");
const onS=()=>{const m=document.documentElement.scrollHeight-innerHeight;bar.style.transform=`scaleX(${m>0?scrollY/m:0})`;h.classList.toggle("sc",scrollY>8)};
addEventListener("scroll",onS,{passive:true});onS();
const io=new IntersectionObserver(es=>es.forEach(e=>{if(!e.isIntersecting)return;const t=e.target;t.classList.add("in");io.unobserve(t);setTimeout(()=>t.classList.remove("rv","in"),1400)}),{threshold:.1,rootMargin:"0px 0px -40px 0px"});
const tag=()=>$$("main h1,main h2,main .lead,main .card,main .box,main .cats a,main .badge,main .detail>*,main .cta,main .hero .btn,main .hero-art,main .promo .wrap>*,main .bk-card").forEach(el=>{if(el.dataset.rv)return;el.dataset.rv=1;const i=[...el.parentElement.children].indexOf(el);el.style.setProperty("--d",Math.min(i,6)*80+"ms");el.classList.add("rv");io.observe(el)});
tag();new MutationObserver(tag).observe($("main"),{childList:true,subtree:true});
document.addEventListener("click",e=>{if(e.target.closest("nav a"))$("#nav").classList.remove("open")});
})();
