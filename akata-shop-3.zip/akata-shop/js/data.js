// ===== EDIT ME: shop details, products, services =====
const AKATA={
  name:"Akata Shop",tagline:"the glow and vitality fixer",
  whatsapp:"265000000000", // country code + number, no + or spaces
  phone:"+265 XXX XXX XXX",email:"info@akata.mw",
  hours:"Monday – Saturday, 8:00 AM – 5:00 PM",
  social:{Facebook:"#",Instagram:"#",TikTok:"#"},
  mapQuery:"Blantyre, Malawi",
  promo:{title:"Glow More. Spend Less.",text:"Discover our latest beauty offers and selected products at special prices.",active:true}
};
const CATEGORIES=[["Skin Care","🧴"],["Face Care","✨"],["Body Care","🌸"],["Brightening","🌟"],["Cleansers","💧"],["Serums","🧪"],["Moisturizers","🥥"],["Oils","🌿"],["Accessories","🪞"]];
const PRODUCTS=[
 {slug:"fair-and-white-so-white-shower-gel-set",name:"Fair & White So White Shower Gel Set",cat:"Body Care",price:45000,desc:"Brightening and exfoliating shower gels with pomegranate & melon extracts.",how:"Use in the shower, massage onto wet skin and rinse. Use the exfoliating gel 2–3 times a week.",avail:true,featured:true,promo:false,icon:"🧴",img:"images/fw-shower-gel-set.jpg"},
 {slug:"fair-and-white-so-white-collection",name:"Fair & White So White Collection",cat:"Brightening",price:85000,desc:"Brightening shower gel, Lait Skin Perfector body milk and brightening oil.",how:"Cleanse with the shower gel, then apply the body milk and a few drops of oil to damp skin.",avail:true,featured:true,promo:false,icon:"✨",img:"images/fw-collection.jpg"},
 {slug:"fair-and-white-lait-skin-perfector",name:"Fair & White Lait Skin Perfector",cat:"Brightening",price:30000,desc:"Brightening and moisturising body milk, 500 ml.",how:"Apply to clean, dry skin every day, massaging until absorbed.",avail:true,featured:true,promo:false,icon:"🌸",img:"images/fw-lait-skin-perfector.jpg"},
 {slug:"nivea-soft-moisturizing-cream",name:"Nivea Soft Moisturising Cream",cat:"Moisturizers",price:12000,sale:10500,desc:"Light, fast-absorbing cream for face, body and hands, 200 ml.",how:"Apply a small amount to face, hands or body whenever skin feels dry.",avail:true,featured:true,promo:true,icon:"🥥",img:"images/nivea-soft-cream.jpg"},
 {slug:"nivea-radiant-and-beauty-lotion",name:"Nivea Radiant & Beauty Body Lotion",cat:"Body Care",price:18000,desc:"Even-glow body lotion that keeps skin soft and moisturised.",how:"Apply to clean skin after bathing, once or twice daily.",avail:true,featured:false,promo:false,icon:"🍊",img:"images/nivea-radiant-lotion.jpg"},
 {slug:"vaseline-healthy-bright-daily-brightening-lotion",name:"Vaseline Daily Brightening Lotion",cat:"Brightening",price:22000,desc:"Non-greasy even tone lotion with Vitamin B3, 725 ml.",how:"Apply all over the body daily, especially after showering.",avail:true,featured:false,promo:false,icon:"🌟",img:"images/vaseline-daily-brightening.jpg"}
];
const SERVICES=[
 {slug:"glow-facial-30-minutes",name:"Glow in 30 Minutes",desc:"A quick express facial that cleanses, refreshes and leaves skin glowing.",duration:"30 minutes",price:"MWK 15,000",icon:"✨",img:"images/facial-glow.jpg",expect:["Skin cleanse","Mask treatment","Gentle face massage","Aftercare advice"]},
 {slug:"signature-facial",name:"Signature Facial",desc:"A relaxing full facial with a nourishing mask to restore your skin's vitality.",duration:"60 minutes",price:"MWK 25,000",icon:"🌿",img:"images/facial-signature.jpg",expect:["Deep cleanse","Gentle exfoliation","Mask and massage","Aftercare advice"]},
 {slug:"beauty-consultation",name:"Beauty Consultation",desc:"Get personalised help choosing products for your skin and routine.",duration:"30 minutes",price:"MWK 5,000",icon:"💬",img:"images/fw-collection.jpg",expect:["Skin consultation","Product guidance","Routine discussion","Recommendations"]}
];
const TESTIMONIALS=[["Great products and friendly service.","Akata Customer"],["I really enjoyed the service and the products were exactly what I needed.","Akata Customer"]];

