const $=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>[...r.querySelectorAll(s)];
const mwk=n=>"MWK "+n.toLocaleString("en-US");
const wa=t=>`https://wa.me/${AKATA.whatsapp}?text=${encodeURIComponent(t)}`;
const store=(k,v)=>v===undefined?JSON.parse(localStorage.getItem(k)||"[]"):localStorage.setItem(k,JSON.stringify(v));
const page=document.body.dataset.page;
const nav=[["index","Home"],["products","Products"],["services","Services"],["about","About Us"],["booking","Booking"],["contact","Contact Us"]];
document.body.insertAdjacentHTML("afterbegin",`<header><div class="wrap nav"><a class="logo" href="index.html"><img src="images/logo.jpg" alt="Akata logo">Akata</a>
<nav id="nav"><ul>${nav.map(([h,t])=>`<li><a href="${h}.html" class="${page===h?"on":""}">${t}</a></li>`).join("")}</ul></nav>
<a class="btn sm" href="booking.html">Book a Service</a><button class="burger" aria-label="Menu" onclick="$('#nav').classList.toggle('open')">☰</button></div></header>`);
document.body.insertAdjacentHTML("beforeend",`<footer><div class="wrap"><div><h3>${AKATA.name}</h3><p>Beauty &amp; Skincare — ${AKATA.tagline}.</p></div>
<div><h3>Quick Links</h3><ul>${nav.map(([h,t])=>`<li><a href="${h}.html">${t}</a></li>`).join("")}</ul></div>
<div><h3>Customer Support</h3><ul><li>${AKATA.phone}</li><li><a href="${wa("Hello Akata Shop")}">WhatsApp</a></li><li>${AKATA.email}</li><li>Blantyre, Malawi</li><li>${AKATA.hours}</li></ul></div>
<div><h3>Follow Us</h3><ul>${Object.entries(AKATA.social).map(([n,u])=>`<li><a href="${u}">${n}</a></li>`).join("")}</ul></div></div>
<p class="copy">© 2026 Akata Shop. All Rights Reserved.</p></footer><a class="wa" href="${wa("Hello Akata Shop, I have a question.")}" aria-label="Chat on WhatsApp">💬</a>`);
const pic=o=>o.img?`<img src="${o.img}" alt="${o.name}" loading="lazy" onerror="this.replaceWith(document.createTextNode('${o.icon}'))">`:o.icon;
const pCard=p=>`<article class="card"><div class="ph">${p.promo?'<span class="tag">Offer</span>':""}${pic(p)}</div><div class="b"><span class="cat">${p.cat}</span><h3>${p.name}</h3><p>${p.desc}</p>
<div><span class="price">${mwk(p.sale||p.price)}</span>${p.sale?`<span class="old">${mwk(p.price)}</span>`:""}${p.avail?"":" <small>(Out of stock)</small>"}</div>
<div class="row"><a class="btn sm" href="product.html?p=${p.slug}">View Product</a><a class="btn sm ghost" href="${wa(`Hello Akata Shop, I would like to enquire about the ${p.name}.`)}">WhatsApp</a></div></div></article>`;
const sCard=s=>`<article class="card"><div class="ph">${pic(s)}</div><div class="b"><h3>${s.name}</h3><p>${s.desc}</p><div><span class="price">${s.price}</span> · ${s.duration}</div>
<div class="row"><a class="btn sm" href="booking.html?s=${s.slug}">Book Now</a><a class="btn sm ghost" href="service.html?s=${s.slug}">Details</a></div></div></article>`;
const Q=k=>new URLSearchParams(location.search).get(k);
if(page==="index"){
 $("#promo").innerHTML=AKATA.promo.active?`<div class="wrap"><div><h2>${AKATA.promo.title}</h2><p>${AKATA.promo.text}</p></div><a class="btn ghost" style="color:#fff" href="products.html?promo=1">View Promotions</a></div>`:"";
 $("#featured").innerHTML=PRODUCTS.filter(p=>p.featured).map(pCard).join("");
 $("#cats").innerHTML=CATEGORIES.map(([c,i])=>`<a href="products.html?cat=${encodeURIComponent(c)}"><span>${i}</span>${c}</a>`).join("");
 $("#svc").innerHTML=SERVICES.map(sCard).join("");
 $("#tests").innerHTML=TESTIMONIALS.map(([q,n])=>`<div class="box"><p class="t">“${q}”</p><p>— ${n}</p></div>`).join("");
}
if(page==="products"){
 $("#fcat").innerHTML='<option value="">All categories</option>'+CATEGORIES.map(([c])=>`<option>${c}</option>`).join("");
 $("#fcat").value=Q("cat")||"";if(Q("promo"))$("#fx").value="promo";
 const draw=()=>{const s=$("#fq").value.toLowerCase(),c=$("#fcat").value,pr=$("#fp").value,x=$("#fx").value;
  const r=PRODUCTS.filter(p=>(!c||p.cat===c)&&(!s||(p.name+p.desc).toLowerCase().includes(s))&&(!pr||(pr==="lo"?p.price<10000:pr==="mid"?p.price>=10000&&p.price<=15000:p.price>15000))&&(x!=="avail"||p.avail)&&(x!=="promo"||p.promo)&&(x!=="feat"||p.featured));
  $("#list").innerHTML=r.map(pCard).join("")||"<p>No products match. Try clearing a filter.</p>"};
 $$(".filters>*").forEach(e=>e.addEventListener("input",draw));draw();
}
if(page==="product"){
 const p=PRODUCTS.find(x=>x.slug===Q("p"))||PRODUCTS[0];document.title=`${p.name} | Akata Shop`;
 $("#d").innerHTML=`<div class="ph">${pic(p)}</div><div><span class="cat" style="color:var(--pink)">${p.cat}</span><h1 style="font-size:2.3rem">${p.name}</h1><p class="price" style="font-size:1.6rem;margin:8px 0">${mwk(p.sale||p.price)}</p>
 <p><strong>${p.avail?"In stock":"Currently unavailable"}</strong></p><p class="lead">${p.desc}</p><h3>How to use</h3><p class="lead">${p.how}</p>
 <div class="row"><a class="btn" href="${wa(`Hello Akata Shop, I would like to enquire about the ${p.name}.`)}">Enquire About This Product</a><a class="btn ghost" href="products.html">Back to Products</a></div>
 <div class="box" style="margin-top:28px"><strong>Looking for help choosing a product?</strong><p><a style="color:var(--pink)" href="booking.html?s=beauty-consultation">Book a Beauty Consultation</a></p></div></div>`;
 $("#rel").innerHTML=PRODUCTS.filter(x=>x.slug!==p.slug).slice(0,4).map(pCard).join("");
}
if(page==="services")$("#svc").innerHTML=SERVICES.map(sCard).join("");
if(page==="service"){
 const s=SERVICES.find(x=>x.slug===Q("s"))||SERVICES[0];
 $("#d").innerHTML=`<div class="ph">${pic(s)}</div><div><h1 style="font-size:2.3rem">${s.name}</h1><p class="lead">${s.desc}</p><h3>What to expect</h3><ul style="margin:8px 0 18px 20px">${s.expect.map(e=>`<li>${e}</li>`).join("")}</ul>
 <p><strong>Duration:</strong> ${s.duration}<br><strong>Price:</strong> ${s.price}<br><strong>Location:</strong> Akata Shop, Blantyre</p><div class="row"><a class="btn" href="booking.html?s=${s.slug}">Book This Service</a></div></div>`;
}
if(page==="booking"){
 const S={};let step=0;const $e=id=>document.getElementById(id);
 const days=[];for(let i=1;days.length<14;i++){const x=new Date();x.setDate(x.getDate()+i);if(x.getDay())days.push(x)}
 const times=[];for(let m=480;m<=990;m+=30){const h=Math.floor(m/60);times.push(`${h>12?h-12:h}:${m%60?"30":"00"} ${h>=12?"PM":"AM"}`)}
 const pre=SERVICES.find(s=>s.slug===Q("s"));if(pre)S.service=pre.name;
 $e("so").innerHTML=SERVICES.map(s=>`<button type="button" class="opt ${S.service===s.name?"sel":""}" data-k="service" data-v="${s.name}"><span class="ic">${s.icon}</span><span><b>${s.name}</b><small>${s.duration} · ${s.price}</small><em>${s.desc}</em></span></button>`).join("");
 $e("dc").innerHTML=days.map(d=>{const l=d.toLocaleDateString("en-GB",{weekday:"short",day:"numeric",month:"short"});return `<button type="button" class="chip" data-k="date" data-v="${l}"><b>${l.split(" ")[0]}</b>${l.split(" ").slice(1).join(" ")}</button>`}).join("");
 $e("tc").innerHTML=times.map(t=>`<button type="button" class="chip" data-k="time" data-v="${t}">${t}</button>`).join("");
 $e("bw").addEventListener("click",e=>{const b=e.target.closest("[data-k]");if(!b)return;S[b.dataset.k]=b.dataset.v;$$(`[data-k="${b.dataset.k}"]`).forEach(x=>x.classList.toggle("sel",x===b));$e("er").textContent=""});
 const err=m=>{$e("er").textContent=m;return false};
 const ok=()=>{if(step===0&&!S.service)return err("Choose a service to continue.");if(step===1&&!(S.date&&S.time))return err("Pick both a date and a time.");
  if(step===2){if(!$e("fn").value.trim())return err("Enter your full name.");if($e("fp").value.replace(/\D/g,"").length<7)return err("Enter a valid phone number.");Object.assign(S,{name:$e("fn").value.trim(),phone:$e("fp").value.trim(),email:$e("fe").value.trim(),people:$e("fg").value||1,notes:$e("fo").value.trim()})}return true};
 const go=n=>{step=n;$$(".panel").forEach((p,i)=>p.classList.toggle("on",i===n));$$("#sp li").forEach((l,i)=>{l.classList.toggle("cur",i===n);l.classList.toggle("done",i<n)});
  $e("bk").classList.toggle("hide",!n);$e("nx").textContent=n===3?"Confirm booking":"Continue";$e("er").textContent="";
  if(n===3)$e("sm").innerHTML=[["Service",S.service],["Date",S.date],["Time",S.time],["Name",S.name],["Phone",S.phone],["People",S.people]].map(([k,v])=>`<div><dt>${k}</dt><dd>${v}</dd></div>`).join("");
  $(".bk-card").scrollIntoView({behavior:"smooth",block:"start"})};
 $e("bk").onclick=()=>go(step-1);
 $e("nx").onclick=()=>{if(!ok())return;if(step<3)return go(step+1);
  const ref="AKT-"+Math.floor(1000+Math.random()*9000);store("akata_bookings",[...store("akata_bookings"),{ref,...S,status:"Pending",created:new Date().toLocaleString()}]);
  $e("bw").innerHTML=`<div class="ok"><svg class="tick" viewBox="0 0 84 84"><circle cx="42" cy="42" r="42"/><path d="M26 43l11 11 21-23"/></svg><h2>Booking request received</h2><p class="lead" style="margin:14px auto 20px">Thank you for booking with Akata Shop. Our team will contact you to confirm your appointment.</p><p><strong>Reference: ${ref}</strong></p><div class="row" style="justify-content:center;margin-top:22px"><a class="btn" href="${wa(`Hello Akata Shop, I just requested a booking (${ref}) for ${S.service} on ${S.date} at ${S.time}.`)}">Message us on WhatsApp</a><a class="btn ghost" href="index.html">Return Home</a></div></div>`;scrollTo({top:0,behavior:"smooth"})};
 go(pre?1:0);
}
if(page==="contact"){
 $("#cm").src="https://www.google.com/maps?q="+encodeURIComponent(AKATA.mapQuery)+"&output=embed";
 $("#ph").textContent=AKATA.phone+" · "+AKATA.email;$("#wl").href=wa("Hello Akata Shop");$("#hr").textContent=AKATA.hours;
 $("#cf").onsubmit=e=>{e.preventDefault();store("akata_messages",[...store("akata_messages"),{...Object.fromEntries(new FormData(e.target)),at:new Date().toLocaleString()}]);e.target.outerHTML='<div class="ok"><h3>Thank you. Your message has been received.</h3></div>'};
}
if(page==="admin"){
 const draw=()=>{const b=store("akata_bookings"),c=s=>b.filter(x=>x.status===s).length;
  $("#stats").innerHTML=[["Products",PRODUCTS.length],["Available",PRODUCTS.filter(p=>p.avail).length],["Featured",PRODUCTS.filter(p=>p.featured).length],["Services",SERVICES.length],["Pending",c("Pending")],["Confirmed",c("Confirmed")]].map(([k,v])=>`<div class="box"><h2>${v}</h2>${k}</div>`).join("");
  $("#bt").innerHTML=b.map((x,i)=>`<tr><td>${x.ref}</td><td>${x.name}<br>${x.phone}</td><td>${x.service}</td><td>${x.date} ${x.time}</td><td>${x.status}</td><td>${["Confirmed","Cancelled","Completed"].map(s=>`<button class="btn sm ghost" onclick="act(${i},'${s}')">${s}</button>`).join(" ")} <button class="btn sm" onclick="act(${i})">Delete</button></td></tr>`).join("")||'<tr><td colspan="6">No bookings yet.</td></tr>'};
 window.act=(i,s)=>{const b=store("akata_bookings");s?b[i].status=s:b.splice(i,1);store("akata_bookings",b);draw()};draw();
}
