AKATA SHOP WEBSITE — open index.html in a browser, or upload the folder to any web host.
Edit js/data.js to change WhatsApp number, phone, email, products, services, promo and testimonials.
Replace images/logo.jpg with your own. admin.html shows bookings stored in the browser (demo only).
